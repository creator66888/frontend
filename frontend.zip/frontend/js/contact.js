/* Fabiha Organic — contact page: POST /api/contact */

(function () {
  document.addEventListener("DOMContentLoaded", function () {
    var form = document.getElementById("contact-form");
    var card = document.getElementById("contact-form-card");
    var errorEl = document.getElementById("cf-error");
    var submitBtn = document.getElementById("cf-submit");
    if (!form) return;

    form.addEventListener("submit", async function (e) {
      e.preventDefault();
      errorEl.classList.add("hidden");

      var payload = {
        name: document.getElementById("cf-name").value.trim(),
        email: document.getElementById("cf-email").value.trim(),
        message: document.getElementById("cf-message").value.trim(),
      };

      if (!payload.name || !payload.email || !payload.message) {
        errorEl.textContent = "Please fill in all fields.";
        errorEl.classList.remove("hidden");
        return;
      }

      submitBtn.disabled = true;
      submitBtn.textContent = "Sending…";

      try {
        var res = await fetch(API_BASE_URL + "/api/contact", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(payload),
        });
        var data = await res.json();
        if (!res.ok || !data.ok) {
          throw new Error((data && data.error) || "Something went wrong");
        }
        card.innerHTML =
          '<div style="text-align:center;padding:2rem 0">' +
          '<span style="font-size:3rem">💌</span>' +
          '<h3 style="margin-top:1rem;font-size:1.5rem;font-weight:700;color:var(--organic-700)">Thank You for Reaching Out!</h3>' +
          '<p style="margin-top:0.5rem;color:var(--gray-500)">Your message has been received. We truly appreciate you taking the time to contact us, and we will get back to you within 24 hours.</p>' +
          "</div>";
      } catch (err) {
        errorEl.textContent = err.message || "Failed to send your message. Please try again.";
        errorEl.classList.remove("hidden");
        submitBtn.disabled = false;
        submitBtn.textContent = "Send Message";
      }
    });
  });
})();