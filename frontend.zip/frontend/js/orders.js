/* Fabiha Organic — owner orders portal */

(function () {
  var TOKEN_KEY = "fabiha_orders_token";
  var token = null;
  var orders = [];

  document.addEventListener("DOMContentLoaded", function () {
    token = localStorage.getItem(TOKEN_KEY);
    if (token) {
      showDashboard();
      loadOrders();
    } else {
      showLogin();
    }

    wireEvents();
  });

  function showLogin() {
    document.getElementById("login-view").classList.remove("hidden");
    document.getElementById("dashboard-view").classList.add("hidden");
  }

  function showDashboard() {
    document.getElementById("login-view").classList.add("hidden");
    document.getElementById("dashboard-view").classList.remove("hidden");
  }

  function wireEvents() {
    var loginForm = document.getElementById("login-form");
    loginForm.addEventListener("submit", onLogin);

    document.getElementById("refresh-btn").addEventListener("click", loadOrders);
    document.getElementById("lock-btn").addEventListener("click", openLockModal);
    document.getElementById("lock-cancel").addEventListener("click", closeLockModal);
    document.getElementById("lock-confirm").addEventListener("click", confirmLock);

    document.addEventListener("click", onStatusClick);
  }

  async function onLogin(e) {
    e.preventDefault();
    var password = document.getElementById("portal-password").value;
    var errorEl = document.getElementById("login-error");
    errorEl.classList.add("hidden");

    try {
      var res = await fetch(API_BASE_URL + "/api/auth", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ password: password }),
      });
      var data = await res.json();
      if (!res.ok || !data.ok) {
        throw new Error("Incorrect password. Please try again.");
      }
      token = data.token;
      localStorage.setItem(TOKEN_KEY, token);
      document.getElementById("portal-password").value = "";
      showDashboard();
      loadOrders();
    } catch (err) {
      errorEl.textContent = err.message || "Login failed";
      errorEl.classList.remove("hidden");
    }
  }

  async function loadOrders() {
    var list = document.getElementById("orders-list");
    var sub = document.getElementById("dash-sub");
    list.innerHTML = '<p style="padding:2rem 0;color:var(--gray-500)">Loading orders…</p>';
    sub.textContent = "Loading orders…";

    try {
      var res = await fetch(API_BASE_URL + "/api/orders", {
        headers: { Authorization: "Bearer " + token },
      });
      var data = await res.json();
      if (res.status === 401) {
        localStorage.removeItem(TOKEN_KEY);
        token = null;
        showLogin();
        return;
      }
      if (!res.ok || !data.ok) throw new Error("Failed to load orders");

      orders = data.orders;
      renderOrders();
    } catch (err) {
      list.innerHTML =
        '<p style="padding:2rem 0;color:#ef4444">' + (err.message || "Failed to load orders") + "</p>";
      sub.textContent = "Error loading orders.";
    }
  }

  function activeOrders() {
    return orders.filter(function (o) { return o.status !== "cancelled"; });
  }

  function parseItems(raw) {
    try {
      return JSON.parse(raw);
    } catch {
      return [];
    }
  }

  function productName(id) {
    var p = window.FabihaData && window.FabihaData.getProduct(id);
    return p ? p.name : id;
  }

  function formatPrice(v) {
    var n = Number(v);
    if (isNaN(n)) return "Rs 0";
    return "Rs " + n.toLocaleString("en-PK");
  }

  function formatDate(iso) {
    var d = new Date(iso);
    if (isNaN(d.getTime())) return iso;
    return d.toLocaleString("en-PK", {
      year: "numeric",
      month: "short",
      day: "numeric",
      hour: "2-digit",
      minute: "2-digit",
    });
  }

  function statusBadge(status) {
    var cls = status === "paid" ? "" : " " + status;
    return (
      '<span class="status-badge' + cls + '">' +
      '<span class="dot"></span>' + String(status).toUpperCase() +
      "</span>"
    );
  }

  function statusControls(id, current) {
    return ["pending", "paid", "cancelled"]
      .map(function (s) {
        var active = s === current ? " active" : "";
        return (
          '<button class="btn-micro' + active + '" type="button" data-status-id="' + id + '" data-status="' + s + '">' +
          s +
          "</button>"
        );
      })
      .join("");
  }

  function orderCardHTML(o) {
    var items = parseItems(o.items);
    return (
      '<div class="order-card">' +
      '<div class="order-card-head">' +
      "<div>" +
      '<p class="order-ref">Order #' + o.order_ref + "</p>" +
      '<p class="order-date">' + formatDate(o.created_at) + "</p>" +
      "</div>" +
      statusBadge(o.status) +
      "</div>" +
      '<div class="order-card-body">' +
      '<div class="order-customer">' +
      '<p class="name">' + o.customer_name + "</p>" +
      "<span>" + o.email + "</span>" +
      "<span>" + o.phone + "</span>" +
      "<span>" + o.address + ", " + o.city + "</span>" +
      '<div class="status-controls">' + statusControls(o.id, o.status) + "</div>" +
      "</div>" +
      '<div class="order-items">' +
      '<p class="items-label">Items</p>' +
      items
        .map(function (it) {
          return "<p>" + productName(it.productId) + " × " + it.qty + "</p>";
        })
        .join("") +
      '<p class="order-total">' + formatPrice(o.total) + "</p>" +
      "</div>" +
      "</div>" +
      "</div>"
    );
  }

  function renderOrders() {
    var list = document.getElementById("orders-list");
    var sub = document.getElementById("dash-sub");
    var active = activeOrders();
    var refreshed = new Date().toLocaleTimeString();

    sub.textContent =
      "Showing " + active.length + " active order" + (active.length === 1 ? "" : "s") +
      " · last refreshed " + refreshed;

    if (active.length === 0) {
      list.innerHTML =
        '<div class="empty-state">' +
        '<span class="empty-state-emoji">📭</span>' +
        '<h2 class="empty-state-title">No active orders</h2>' +
        '<p class="empty-state-sub">New customer orders will appear here.</p>' +
        "</div>";
      return;
    }

    list.innerHTML = active.map(orderCardHTML).join("");
  }

  function currentStatus(id) {
    var o = orders.find(function (x) { return x.id === id; });
    return o ? o.status : null;
  }

  async function onStatusClick(e) {
    var btn = e.target.closest("[data-status-id]");
    if (!btn) return;

    var id = Number(btn.dataset.statusId);
    var status = btn.dataset.status;
    if (status === currentStatus(id)) return;

    try {
      var res = await fetch(API_BASE_URL + "/api/orders/" + id, {
        method: "PATCH",
        headers: {
          "Content-Type": "application/json",
          Authorization: "Bearer " + token,
        },
        body: JSON.stringify({ status: status }),
      });
      var data = await res.json();
      if (res.status === 401) {
        localStorage.removeItem(TOKEN_KEY);
        token = null;
        showLogin();
        return;
      }
      if (!res.ok || !data.ok) throw new Error("Update failed");
      loadOrders();
    } catch (err) {
      alert(err.message || "Could not update order status");
    }
  }

  function openLockModal() {
    document.getElementById("lock-modal").classList.remove("hidden");
  }

  function closeLockModal() {
    document.getElementById("lock-modal").classList.add("hidden");
  }

  function confirmLock() {
    localStorage.removeItem(TOKEN_KEY);
    token = null;
    closeLockModal();
    showLogin();
  }
})();