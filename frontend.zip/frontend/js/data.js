/* Fabiha Organic — product catalog data (from src/lib/products.ts) */

/* Backend API base URL (Vercel deployment). */
var API_BASE_URL = "https://fabiha-organic-c7573xxte-creator66888.vercel.app";

const CATEGORIES = [
  {
    id: "soap",
    label: "Herbal Soaps",
    blurb: "Artisan soaps crafted with pure botanical extracts to cleanse, nourish, and rejuvenate your skin naturally.",
  },
  {
    id: "shampoo",
    label: "Shampoo",
    blurb: "A gentle, herbal shampoo that strengthens from root to tip — for hair that looks as healthy as it feels.",
  },
  {
    id: "toner",
    label: "Toner",
    blurb: "A refreshing botanical mist that tightens, hydrates, and restores your skin's natural balance after every wash.",
  },
  {
    id: "lipbalm",
    label: "Lip Balm",
    blurb: "A rich, natural balm infused with rose to deeply hydrate, heal, and protect your lips all day long.",
  },
];

const PRODUCTS = [
  {
    id: "soap_herbal",
    slug: "herbal-soap",
    name: "Herbal Soap",
    category: "soap",
    price: 349,
    unit: "per bar",
    tagline: "A masterful blend of time-honoured herbs for radiant, healthy skin.",
    description:
      "Our signature Herbal Soap is a carefully balanced fusion of pure botanicals and cold-pressed natural oils. Each bar is hand-cut and cured to deliver a gentle yet thorough cleanse that leaves your skin feeling remarkably soft, refreshed, and naturally radiant — day after day.",
    benefits: [
      "Soothes and revitalises tired skin",
      "Authentic herbal fragrance from pure botanicals",
      "Perfect for gentle daily cleansing",
      "Completely free from harsh chemicals and synthetics",
    ],
    emoji: "🌿",
    featured: true,
  },
  {
    id: "soap_neem",
    slug: "neem-soap",
    name: "Neem Soap",
    category: "soap",
    price: 349,
    unit: "per bar",
    tagline: "Purifying neem extract for unmistakably clean, clear skin.",
    description:
      "Renowned for centuries in traditional skincare, neem is nature's most powerful purifier. Our Neem Soap harnesses this ancient botanical to deeply cleanse, clarify, and protect your skin — leaving it visibly clearer and beautifully balanced with every wash.",
    benefits: [
      "Naturally antibacterial and deeply purifying",
      "Helps reduce blemishes and imperfections",
      "Ideal for oily and combination skin types",
      "Provides a refreshing, cooling sensation",
    ],
    emoji: "🫧",
    featured: true,
  },
  {
    id: "soap_rose",
    slug: "rose-soap",
    name: "Rose Soap",
    category: "soap",
    price: 349,
    unit: "per bar",
    tagline: "Pure rose petals for skin that glows with natural beauty.",
    description:
      "Infused with genuine rose essence, our Rose Soap transforms your daily cleanse into an indulgent ritual. The delicate floral aroma calms the mind while the nourishing formula leaves your skin feeling impossibly soft, supple, and radiantly alive.",
    benefits: [
      "Deeply softens and rejuvenates skin",
      "Enchanting natural rose fragrance",
      "Imparts a beautiful, healthy glow",
      "Rich in moisture-binding botanicals",
    ],
    emoji: "🌹",
    featured: true,
  },
  {
    id: "soap_sandal",
    slug: "sandal-soap",
    name: "Sandal Soap",
    category: "soap",
    price: 349,
    unit: "per bar",
    tagline: "Warm sandalwood for deeply calm, nourished skin.",
    description:
      "Sandalwood has been treasured for millennia for its extraordinary soothing properties. Our Sandal Soap captures this ancient wisdom in a luxurious bar that calms your senses with its warm, woody aroma while gently hydrating and caring for your skin.",
    benefits: [
      "Deeply calms and soothes irritated skin",
      "Authentic warm sandalwood aroma",
      "Intensely hydrating botanical formula",
      "Crafted with skin-nourishing natural oils",
    ],
    emoji: "🪵",
  },
  {
    id: "soap_coffee",
    slug: "coffee-soap",
    name: "Coffee Soap",
    category: "soap",
    price: 349,
    unit: "per bar",
    tagline: "Energising coffee grounds for smooth, luminous skin.",
    description:
      "Blended with finely ground coffee, our Coffee Soap delivers a luxurious exfoliating experience that buffs away dullness, stimulates circulation, and reveals the smooth, vibrant skin beneath. An invigorating treat that awakens both your skin and your senses.",
    benefits: [
      "Gently polishes and exfoliates",
      "Reveals your skin's natural radiance",
      "Uplifting, authentic coffee aroma",
      "Visibly smooths rough, dry patches",
    ],
    emoji: "☕",
  },
  {
    id: "shampoo_herbal",
    slug: "herbal-shampoo",
    name: "Herbal Shampoo",
    category: "shampoo",
    price: 399,
    unit: "per 250ml bottle",
    tagline: "Time-tested botanicals for visibly stronger, more lustrous hair.",
    description:
      "Our Herbal Shampoo is a potent blend of nature's finest hair-care botanicals, formulated to gently cleanse your scalp while strengthening each strand from root to tip. The result is hair that looks undeniably healthier, shinier, and full of natural vitality.",
    benefits: [
      "Strengthens and fortifies hair from root to tip",
      "Soothes and nourishes the scalp",
      "Adds brilliant shine and silky softness",
      "Gentle, herbal formula for everyday use",
    ],
    emoji: "🧴",
    featured: true,
  },
  {
    id: "toner_herbal",
    slug: "herbal-toner",
    name: "Herbal Toner",
    category: "toner",
    price: 199,
    unit: "per 120ml bottle",
    tagline: "A refreshing botanical mist for beautifully balanced, dewy skin.",
    description:
      "Our Herbal Toner is a finely crafted botanical mist that revitalises your skin with every spritz. Formulated with pure herbal extracts, it tightens pores, restores your skin's natural pH, and delivers a wave of hydration that leaves your complexion looking fresh, luminous, and perfectly balanced.",
    benefits: [
      "Instantly refreshes and tightens skin",
      "Restores your skin's natural pH balance",
      "Delivers deep, lasting hydration",
      "Reveals a brighter, more even complexion",
    ],
    emoji: "💧",
    featured: true,
  },
  {
    id: "lipbalm_rose",
    slug: "rose-lipbam",
    name: "Rose Lip Balm",
    category: "lipbalm",
    price: 199,
    unit: "per 10g tin",
    tagline: "Luxurious rose-infused balm for irresistibly soft, beautiful lips.",
    description:
      "Our Rose Lip Balm is a rich, velvety formula that melts effortlessly onto your lips, delivering intense hydration and protection. Infused with genuine rose, it heals dry, chapped lips while leaving a gorgeous subtle tint and the most delicate floral scent.",
    benefits: [
      "Provides deep, long-lasting hydration",
      "Heals and softens severely dry lips",
      "Beautiful natural rose tint",
      "Enriched with nourishing botanical oils",
    ],
    emoji: "💄",
    featured: true,
  },
];

/* ---------- Helpers ---------- */
function formatPrice(rupees) {
  return `Rs ${Number(rupees).toFixed(0)}`;
}

function getProduct(id) {
  return PRODUCTS.find((p) => p.id === id);
}

function byCategory(catId) {
  return PRODUCTS.filter((p) => p.category === catId);
}

function productCardHTML(product, compact = false) {
  const benefits = compact
    ? ""
    : `<ul class="product-benefits">${product.benefits
        .slice(0, 3)
        .map((b) => `<li><span class="check">✓</span> ${b}</li>`)
        .join("")}</ul>`;

  return `
    <div class="product-card card-hover">
      <div class="product-card-top">
        <span class="product-emoji">${product.emoji}</span>
        ${product.featured ? '<span class="bestseller-badge">Bestseller</span>' : ""}
      </div>
      <h3 class="product-name">${product.name}</h3>
      <p class="product-tagline">${product.tagline}</p>
      ${benefits}
      <div class="product-footer">
        <div class="product-price-row">
          <span class="product-price">${formatPrice(product.price)}</span>
          <span class="product-unit">${product.unit}</span>
        </div>
        <button class="btn btn-primary add-to-cart" data-product-id="${product.id}">Add to Cart</button>
      </div>
    </div>
  `;
}

function openCartDrawerIfAvailable() {
  if (typeof FabihaCart !== "undefined") {
    FabihaCart.openDrawer();
  }
}

/* ---- Expose globals ---- */
window.FabihaData = {
  CATEGORIES: CATEGORIES,
  PRODUCTS: PRODUCTS,
  formatPrice: formatPrice,
  getProduct: getProduct,
  byCategory: byCategory,
  productCardHTML: productCardHTML,
};

/* Load the cart script on pages that include it, and bind "Add to Cart" clicks. */
document.addEventListener("click", function (e) {
  const btn = e.target.closest(".add-to-cart");
  if (!btn) return;
  const id = btn.dataset.productId;
  const product = getProduct(id);
  if (!product) return;
  if (typeof FabihaCart !== "undefined") {
    FabihaCart.addItem(product);
    FabihaCart.openDrawer();
  }
});