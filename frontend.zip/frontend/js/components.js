/* Fabiha Organic — shared layout components (navbar, footer, cart drawer shell) */

(function () {
  const NAV_LINKS = [
    { href: "index.html", label: "Home" },
    { href: "products.html", label: "Products" },
    { href: "about.html", label: "About" },
    { href: "contact.html", label: "Contact" },
    { href: "order.html", label: "Order Now" },
  ];

  const CAT_QUICK = [
    { href: "products.html#soap", label: "Herbal Soaps" },
    { href: "products.html#shampoo", label: "Shampoo" },
    { href: "products.html#toner", label: "Toner" },
    { href: "products.html#lipbalm", label: "Lip Balm" },
  ];

  function currentPage() {
    const path = window.location.pathname.split("/").pop() || "index.html";
    return path;
  }

  function navbarHTML() {
    const page = currentPage();
    const links = NAV_LINKS.map((l) => {
      const active = l.href === page ? " active" : "";
      return `<a class="nav-link${active}" href="${l.href}">${l.label}</a>`;
    }).join("");

    return `
      <header class="navbar" id="site-navbar">
        <div class="container navbar-inner">
          <a class="brand" href="index.html">
            <span class="brand-icon">🌿</span>
            <span class="brand-text">
              <span class="brand-name">Fabiha Organic</span>
              <span class="brand-tag">Pure • Natural • Handmade</span>
            </span>
          </a>
          <nav class="nav-links">${links}</nav>
          <div class="nav-actions">
            <button class="cart-btn" id="cart-open-btn" aria-label="Open cart">
              <span class="cart-cart-icon">🛒</span>
              <span class="cart-label">Cart</span>
              <span class="cart-count hidden" id="cart-count-badge">0</span>
            </button>
            <button class="menu-btn" id="menu-toggle" aria-label="Menu">☰</button>
          </div>
        </div>
        <nav class="mobile-nav hidden" id="mobile-nav">
          <div class="mobile-links">
            ${NAV_LINKS.map(
              (l) =>
                `<a class="mobile-link" href="${l.href}">${l.label}</a>`
            ).join("")}
          </div>
          <div class="mobile-cats">
            ${CAT_QUICK.map(
              (c) => `<a class="mobile-cat" href="${c.href}">${c.label}</a>`
            ).join("")}
          </div>
        </nav>
      </header>
    `;
  }

  function footerHTML() {
    const featured = window.FabihaData
      ? window.FabihaData.PRODUCTS.slice(0, 5)
      : [];

    const catLinks = window.FabihaData
      ? window.FabihaData.CATEGORIES.map(
          (c) =>
            `<li><a class="footer-link" href="products.html#${c.id}">${c.label}</a></li>`
        ).join("")
      : "";

    const featLinks = featured
      .map(
        (p) =>
          `<li><a class="footer-link" href="products.html#${p.id}">${p.name}</a></li>`
      )
      .join("");

    const year = new Date().getFullYear();

    return `
      <footer class="footer">
        <div class="container footer-grid">
          <div>
            <div class="footer-brand">
              <span class="footer-brand-icon">🌿</span>
              <span class="footer-brand-name">Fabiha Organic</span>
            </div>
            <p class="footer-blurb">
              Handcrafted herbal soaps and skincare made with pure, natural
              ingredients. We believe in the power of nature to nurture your
              skin — gentle on you, kind to the planet.
            </p>
          </div>

          <div>
            <h4 class="footer-heading">Shop by Category</h4>
            <ul class="footer-links">${catLinks}</ul>
          </div>

          <div>
            <h4 class="footer-heading">Quick Links</h4>
            <ul class="footer-links">
              <li><a class="footer-link" href="about.html">Our Story</a></li>
              <li><a class="footer-link" href="contact.html">Get in Touch</a></li>
              <li><a class="footer-link" href="order.html">Place an Order</a></li>
            </ul>
          </div>

          <div>
            <h4 class="footer-heading">Featured Products</h4>
            <ul class="footer-links">${featLinks}</ul>
          </div>
        </div>
        <div class="footer-bottom">
          <div class="container">
            © ${year} Fabiha Organic. All rights reserved. Crafted with care in Pakistan. 🌱
          </div>
        </div>
      </footer>
    `;
  }

  function cartDrawerHTML() {
    return `
      <div class="overlay closed" id="cart-overlay"></div>
      <aside class="cart-drawer closed" id="cart-drawer" aria-label="Shopping cart">
        <div class="drawer-header">
          <h2 class="drawer-title">Your Cart</h2>
          <button class="close-btn" id="cart-close-btn" aria-label="Close cart">✕</button>
        </div>
        <div class="drawer-body" id="cart-body"></div>
        <div class="drawer-footer" id="cart-footer"></div>
      </aside>
    `;
  }

  function boot() {
    const navbarSlot = document.getElementById("navbar-slot");
    const footerSlot = document.getElementById("footer-slot");
    const drawerSlot = document.getElementById("cart-slot");

    if (navbarSlot) navbarSlot.innerHTML = navbarHTML();
    if (footerSlot) footerSlot.innerHTML = footerHTML();
    if (drawerSlot) drawerSlot.innerHTML = cartDrawerHTML();

    /* Mobile menu toggle */
    const toggle = document.getElementById("menu-toggle");
    const mobileNav = document.getElementById("mobile-nav");
    if (toggle && mobileNav) {
      toggle.addEventListener("click", function () {
        const isHidden = mobileNav.classList.contains("hidden");
        mobileNav.classList.toggle("hidden");
        toggle.textContent = isHidden ? "✕" : "☰";
      });
    }
  }

  document.addEventListener("DOMContentLoaded", boot);

  window.FabihaComponents = { boot };
})();