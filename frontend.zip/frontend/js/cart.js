/* Fabiha Organic — cart state + drawer UI (global window.FabihaCart) */

(function () {
  const STORAGE_KEY = "fabiha-cart";

  let items = []; // [{id: string, qty: number}]
  let drawerOpen = false;

  /* ---- persistence ---- */
  function load() {
    try {
      const raw = localStorage.getItem(STORAGE_KEY);
      if (raw) {
        items = JSON.parse(raw).filter(function (i) {
          return window.FabihaData && window.FabihaData.PRODUCTS.some(function (p) {
            return p.id === i.id;
          });
        });
      } else {
        items = [];
      }
    } catch {
      items = [];
    }
  }

  function save() {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(items));
    } catch {
      /* ignore */
    }
  }

  /* ---- cart actions ---- */
  function addItem(product, qty) {
    qty = qty || 1;
    var existing = items.find(function (i) { return i.id === product.id; });
    if (existing) {
      existing.qty += qty;
    } else {
      items.push({ id: product.id, qty: qty });
    }
    save();
    render();
  }

  function removeItem(productId) {
    items = items.filter(function (i) { return i.id !== productId; });
    save();
    render();
  }

  function setQty(productId, qty) {
    if (qty <= 0) {
      removeItem(productId);
      return;
    }
    items.forEach(function (i) {
      if (i.id === productId) i.qty = qty;
    });
    save();
    render();
  }

  function clear() {
    items = [];
    save();
    render();
  }

  function getItems() { return items.slice(); }

  function getCount() {
    return items.reduce(function (s, i) { return s + i.qty; }, 0);
  }

  function getSubtotal() {
    return items.reduce(function (s, i) {
      var p = window.FabihaData && window.FabihaData.PRODUCTS.find(function (x) { return x.id === i.id; });
      return s + (p ? p.price * i.qty : 0);
    }, 0);
  }

  /* ---- drawer ---- */
  function openDrawer() {
    drawerOpen = true;
    renderDrawerVisibility();
  }

  function closeDrawer() {
    drawerOpen = false;
    renderDrawerVisibility();
  }

  function renderDrawerVisibility() {
    var overlay = document.getElementById("cart-overlay");
    var drawer = document.getElementById("cart-drawer");
    if (!overlay || !drawer) return;
    overlay.classList.toggle("open", drawerOpen);
    overlay.classList.toggle("closed", !drawerOpen);
    drawer.classList.toggle("open", drawerOpen);
    drawer.classList.toggle("closed", !drawerOpen);
  }

  function renderDrawerBody() {
    var body = document.getElementById("cart-body");
    var footer = document.getElementById("cart-footer");
    if (!body) return;

    if (items.length === 0) {
      body.innerHTML =
        '<div class="drawer-empty">' +
        '<span style="font-size:3rem">🛒</span>' +
        "<p>Your cart is empty.</p>" +
        '<button class="btn" id="cart-empty-continue">Continue shopping</button>' +
        "</div>";
      if (footer) footer.innerHTML = "";
      var contBtn = document.getElementById("cart-empty-continue");
      if (contBtn) contBtn.addEventListener("click", closeDrawer);
      return;
    }

    var html = '<ul class="cart-item-list">';
    items.forEach(function (item) {
      var p = window.FabihaData && window.FabihaData.PRODUCTS.find(function (x) { return x.id === item.id; });
      if (!p) return;
      html +=
        '<li class="cart-item">' +
        '<span class="cart-item-emoji">' + p.emoji + "</span>" +
        '<div class="cart-item-info">' +
        '<p class="cart-item-name">' + p.name + "</p>" +
        '<p class="cart-item-sub">' + formatPrice(p.price) + " / " + p.unit + "</p>" +
        '<div class="qty-controls">' +
        '<button class="qty-btn" data-qty-id="' + p.id + '" data-qty-action="decrement">−</button>' +
        '<span class="qty-value">' + item.qty + "</span>" +
        '<button class="qty-btn" data-qty-id="' + p.id + '" data-qty-action="increment">+</button>' +
        '<button class="remove-btn" data-remove-id="' + p.id + '">Remove</button>' +
        "</div></div>" +
        '<span class="cart-item-total">' + formatPrice(p.price * item.qty) + "</span>" +
        "</li>";
    });
    html += "</ul>";
    body.innerHTML = html;

    if (footer) {
      footer.innerHTML =
        '<div class="subtotal-row">' +
        '<span class="subtotal-label">Subtotal</span>' +
        '<span class="subtotal-value">' + formatPrice(getSubtotal()) + "</span>" +
        "</div>" +
        '<a class="btn btn-primary btn-block" href="order.html">Proceed to Checkout →</a>';
    }
  }

  function renderCountBadge() {
    var badge = document.getElementById("cart-count-badge");
    if (!badge) return;
    var count = getCount();
    badge.textContent = count;
    badge.classList.toggle("hidden", count === 0);
  }

  function render() {
    renderCountBadge();
    renderDrawerBody();
    document.dispatchEvent(new CustomEvent("fabiha:cart-change"));
  }

  /* ---- wire events ---- */
  function wireEvents() {
    var openBtn = document.getElementById("cart-open-btn");
    var closeBtn = document.getElementById("cart-close-btn");
    var overlay = document.getElementById("cart-overlay");

    if (openBtn) openBtn.addEventListener("click", openDrawer);
    if (closeBtn) closeBtn.addEventListener("click", closeDrawer);
    if (overlay) overlay.addEventListener("click", closeDrawer);

    document.addEventListener("click", function (e) {
      var qtyBtn = e.target.closest("[data-qty-action]");
      if (qtyBtn) {
        var id = qtyBtn.dataset.qtyId;
        var action = qtyBtn.dataset.qtyAction;
        var item = items.find(function (i) { return i.id === id; });
        if (!item) return;
        setQty(id, action === "increment" ? item.qty + 1 : item.qty - 1);
        return;
      }

      var removeBtn = e.target.closest("[data-remove-id]");
      if (removeBtn) {
        removeItem(removeBtn.dataset.removeId);
        return;
      }
    });
  }

  function init() {
    load();
    render();
    wireEvents();
  }

  document.addEventListener("DOMContentLoaded", init);

  function formatPrice(rupees) {
    return "Rs " + Number(rupees).toFixed(0);
  }

  /* Expose API globally */
  window.FabihaCart = {
    addItem: addItem,
    removeItem: removeItem,
    setQty: setQty,
    clear: clear,
    getItems: getItems,
    getCount: getCount,
    getSubtotal: getSubtotal,
    openDrawer: openDrawer,
    closeDrawer: closeDrawer,
    render: render,
    formatPrice: formatPrice,
  };
})();