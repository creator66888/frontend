/* Fabiha Organic — order/checkout page */

(function () {
  var bankConfig = null;

  document.addEventListener("DOMContentLoaded", function () {
    if (!window.FabihaCart || !window.FabihaData) return;

    var form = document.getElementById("order-form");
    var emptyCart = document.getElementById("empty-cart");
    var submitBtn = document.getElementById("o-submit");

    function renderSummary() {
      var items = window.FabihaCart.getItems();
      var list = document.getElementById("order-summary-items");
      var subtotal = window.FabihaCart.getSubtotal();

      list.innerHTML = items
        .map(function (item) {
          var p = window.FabihaData.getProduct(item.id);
          if (!p) return "";
          return (
            '<li>' +
            '<span class="cart-item-emoji" style="width:3rem;height:3rem;font-size:1.5rem">' + p.emoji + "</span>" +
            '<div style="flex:1;min-width:0">' +
            '<p style="font-weight:600;color:var(--gray-800)">' + p.name + "</p>" +
            '<div class="qty-controls">' +
            '<button class="qty-btn" type="button" data-o-id="' + p.id + '" data-o-action="minus">−</button>' +
            '<span class="qty-value">' + item.qty + "</span>" +
            '<button class="qty-btn" type="button" data-o-id="' + p.id + '" data-o-action="plus">+</button>' +
            '<button class="remove-btn" type="button" data-o-remove="' + p.id + '">Remove</button>' +
            "</div>" +
            "</div>" +
            '<span style="font-weight:700;color:var(--organic-700);white-space:nowrap">' +
            window.FabihaData.formatPrice(p.price * item.qty) +
            "</span>" +
            "</li>"
          );
        })
        .join("");

      document.getElementById("o-subtotal").textContent = window.FabihaData.formatPrice(subtotal);
      document.getElementById("o-total").textContent = window.FabihaData.formatPrice(subtotal);
    }

    function toggleViews() {
      var hasItems = window.FabihaCart.getItems().length > 0;
      form.classList.toggle("hidden", !hasItems);
      emptyCart.classList.toggle("hidden", hasItems);
    }

    function loadBankDetails() {
      var box = document.getElementById("bank-box");
      var loading = document.getElementById("bank-loading");
      var details = document.getElementById("bank-details");
      if (!box) return;

      fetch(API_BASE_URL + "/api/config")
        .then(function (res) { return res.json(); })
        .then(function (data) {
          if (!data.ok) throw new Error("not available");
          bankConfig = data.config;
          document.getElementById("bank-name").textContent = bankConfig.bankName;
          document.getElementById("bank-title").textContent = bankConfig.accountTitle;
          document.getElementById("bank-account").textContent = bankConfig.accountNumber;
          document.getElementById("bank-iban").textContent = bankConfig.iban;
          loading.classList.add("hidden");
          details.classList.remove("hidden");
        })
        .catch(function () {
          loading.textContent = "Payment details coming soon.";
        });
    }

    function buildOrderMessage(payload, order) {
      var D = window.FabihaData;
      var items = order ? order.items : payload.items;
      var parsed = typeof items === "string" ? JSON.parse(items) : items;
      var total = order ? order.total : payload.total;

      var lines = [];
      lines.push("🧼 New Order — Fabiha Organic");
      lines.push("----------------------------------");
      lines.push("Order: " + (order ? order.order_ref : "—"));
      lines.push("Name: " + payload.name);
      lines.push("Email: " + payload.email);
      lines.push("Phone: " + payload.phone);
      lines.push("City: " + payload.city);
      lines.push("Address: " + payload.address);
      lines.push("");
      lines.push("Order items:");
      parsed.forEach(function (it) {
        var p = D.getProduct(it.productId);
        if (!p) return;
        lines.push("- " + p.name + " x" + it.qty + " = " + D.formatPrice(p.price * it.qty));
      });
      lines.push("");
      lines.push("Subtotal: " + D.formatPrice(total));
      lines.push("Delivery: FREE");
      lines.push("Total: " + D.formatPrice(total));
      lines.push("----------------------------------");
      lines.push("Payment: Bank Transfer");
      if (bankConfig) {
        lines.push("Bank: " + bankConfig.bankName);
        lines.push("Account Holder: " + bankConfig.accountTitle);
        lines.push("Account Number: " + bankConfig.accountNumber);
        lines.push("IBAN: " + bankConfig.iban);
      }
      lines.push("");
      lines.push("We will not start processing your order until you make the payment.");
      return lines.join("\n");
    }

    function clearFieldErrors() {
      ["o-name", "o-email", "o-phone", "o-address", "o-city"].forEach(function (id) {
        var el = document.getElementById(id);
        if (el) el.style.borderColor = "";
      });
      var err = document.getElementById("o-form-error");
      if (err) err.classList.add("hidden");
    }

    function markInvalid(id) {
      var el = document.getElementById(id);
      if (el) {
        el.style.borderColor = "#ef4444";
        if (el.value.trim() === "") el.focus();
      }
    }

    function showCopyConfirmation() {
      var confirmEl = document.getElementById("copy-confirm");
      if (confirmEl) confirmEl.classList.remove("hidden");
    }

    function resetCopyButton() {
      submitBtn.disabled = false;
      submitBtn.textContent = "📋 Copy Order Details";
    }

    submitBtn.addEventListener("click", async function (e) {
      e.preventDefault();
      clearFieldErrors();

      var payload = {
        name: document.getElementById("o-name").value.trim(),
        email: document.getElementById("o-email").value.trim(),
        phone: document.getElementById("o-phone").value.trim(),
        address: document.getElementById("o-address").value.trim(),
        city: document.getElementById("o-city").value.trim(),
        items: window.FabihaCart.getItems(),
        total: window.FabihaCart.getSubtotal(),
      };

      var required = [
        ["o-name", "Your Name"],
        ["o-email", "Email"],
        ["o-phone", "Phone Number"],
        ["o-address", "Delivery Address"],
        ["o-city", "City"],
      ];

      var missing = [];
      required.forEach(function (pair) {
        var el = document.getElementById(pair[0]);
        if (!el.value.trim()) {
          missing.push(pair[1]);
          markInvalid(pair[0]);
        }
      });

      if (missing.length > 0) {
        var formErr = document.getElementById("o-form-error");
        if (formErr) {
          formErr.textContent = "Please fill in: " + missing.join(", ") + ".";
          formErr.classList.remove("hidden");
        }
        return;
      }

      var validEmail = /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(payload.email);
      if (!validEmail) {
        markInvalid("o-email");
        var emailErr = document.getElementById("o-form-error");
        if (emailErr) {
          emailErr.textContent = "Please enter a valid email address.";
          emailErr.classList.remove("hidden");
        }
        return;
      }

      if (payload.items.length === 0) return;

      submitBtn.disabled = true;
      submitBtn.textContent = "Saving & copying…";

      try {
        var res = await fetch(API_BASE_URL + "/api/orders", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(payload),
        });
        var data = await res.json();
        if (!res.ok || !data.ok) {
          throw new Error((data && data.error) || "Could not place order");
        }

        var msg = buildOrderMessage(payload, data.order);
        try {
          await navigator.clipboard.writeText(msg);
        } catch (copyErr) {
          /* clipboard may be blocked — still confirm the order was saved */
        }

        submitBtn.textContent = "✅ Copied! Paste & Send It To Us";
        showCopyConfirmation();
        setTimeout(resetCopyButton, 3000);
      } catch (err) {
        alert(err.message || "Something went wrong. Please try again.");
        resetCopyButton();
      }
    });

    document.addEventListener("click", function (e) {
      var plus = e.target.closest("[data-o-action='plus']");
      var minus = e.target.closest("[data-o-action='minus']");
      var remove = e.target.closest("[data-o-remove]");

      var item = window.FabihaCart.getItems().find(function (i) {
        return plus ? i.id === plus.dataset.oId : minus ? i.id === minus.dataset.oId : remove ? i.id === remove.dataset.oRemove : false;
      });
      if (!item) return;

      if (plus) window.FabihaCart.setQty(item.id, item.qty + 1);
      if (minus) window.FabihaCart.setQty(item.id, item.qty - 1);
      if (remove) window.FabihaCart.removeItem(item.id);

      renderSummary();
      toggleViews();
    });

    /* Keep page in sync when cart changes from the navbar drawer */
    document.addEventListener("fabiha:cart-change", function () {
      renderSummary();
      toggleViews();
    });

    renderSummary();
    toggleViews();
    loadBankDetails();
  });
})();